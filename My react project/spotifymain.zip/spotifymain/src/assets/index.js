import loader from './loader.svg';
import logo from './logo.svg';

export {
  logo,
  loader,
};
