React project on Spotify Clone 
