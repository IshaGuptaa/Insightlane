Dashboard web-application using react
